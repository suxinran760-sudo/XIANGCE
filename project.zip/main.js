const { app, BrowserWindow, session } = require('electron');
const path = require('path');

function createWindow() {
  const win = new BrowserWindow({
    width: 1280, height: 800,
    backgroundColor: '#070c22',
    autoHideMenuBar: true,
    title: '哈基米',
    icon: path.join(__dirname, 'icon.ico'),
    webPreferences: { contextIsolation: true }
  });
  win.setMenuBarVisibility(false);
  win.on('page-title-updated', e => e.preventDefault());
  win.webContents.on('before-input-event', (e, input) => {
    if (input.type === 'keyDown' && input.key === 'F11') {
      win.setFullScreen(!win.isFullScreen());
      e.preventDefault();
    }
  });
  win.loadFile(path.join(__dirname, 'index.html'));
}

app.whenReady().then(() => {
  const ok = p => p === 'media' || p === 'fullscreen';
  session.defaultSession.setPermissionRequestHandler((wc, p, cb) => cb(ok(p)));
  session.defaultSession.setPermissionCheckHandler((wc, p) => ok(p));
  createWindow();
});
app.on('window-all-closed', () => app.quit());
