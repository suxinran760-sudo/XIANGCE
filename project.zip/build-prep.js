// 构建时：把 three.js 嵌进 index.html，并把手势库复制到本地（完全离线）
const fs = require('fs');
let html = fs.readFileSync('index.html', 'utf8');
const three = fs.readFileSync('node_modules/three/build/three.min.js', 'utf8')
  .replace(/<\/script/gi, '<\\/script');
const re = /<!-- THREE_INLINE_START -->[\s\S]*?<!-- THREE_INLINE_END -->/;
if (!re.test(html)) throw new Error('marker not found');
html = html.replace(re, () => '<script>' + three + '</script>');
fs.writeFileSync('index.html', html);
fs.mkdirSync('mediapipe/hands', { recursive: true });
fs.cpSync('node_modules/@mediapipe/hands', 'mediapipe/hands', { recursive: true });
console.log('prep ok');
